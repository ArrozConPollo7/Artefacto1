"use client";

import { useEffect, useRef, useState } from "react";
import PhotonicCenotaph from "@/components/PhotonicCenotaph"; // adjust path

// ─── Particle canvas background ──────────────────────────────────────────────
function ParticleField() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    let W = (c.width = window.innerWidth);
    let H = (c.height = window.innerHeight);

    const STAR_COUNT = 120;
    const stars = Array.from({ length: STAR_COUNT }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 1.1 + 0.2,
      vx: (Math.random() - 0.5) * 0.12,
      vy: (Math.random() - 0.5) * 0.12,
      alpha: Math.random() * 0.5 + 0.15,
    }));

    let raf: number;
    const draw = () => {
      ctx.clearRect(0, 0, W, H);
      stars.forEach((s) => {
        s.x = (s.x + s.vx + W) % W;
        s.y = (s.y + s.vy + H) % H;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180,180,220,${s.alpha})`;
        ctx.fill();
      });
      // Draw connecting lines between nearby stars
      for (let i = 0; i < stars.length; i++) {
        for (let j = i + 1; j < stars.length; j++) {
          const dx = stars[i].x - stars[j].x;
          const dy = stars[i].y - stars[j].y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < 110) {
            ctx.beginPath();
            ctx.moveTo(stars[i].x, stars[i].y);
            ctx.lineTo(stars[j].x, stars[j].y);
            ctx.strokeStyle = `rgba(150,150,200,${0.06 * (1 - d / 110)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }
      raf = requestAnimationFrame(draw);
    };
    draw();

    const onResize = () => {
      W = c.width = window.innerWidth;
      H = c.height = window.innerHeight;
    };
    window.addEventListener("resize", onResize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", onResize); };
  }, []);

  return (
    <canvas
      ref={ref}
      style={{
        position: "fixed", inset: 0, zIndex: 0,
        pointerEvents: "none", opacity: 0.6,
      }}
    />
  );
}

// ─── Glitch text hook ─────────────────────────────────────────────────────────
function useGlitch(text: string, interval = 3200) {
  const [display, setDisplay] = useState(text);
  useEffect(() => {
    const CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
    let timeout: ReturnType<typeof setTimeout>;
    const glitch = () => {
      let i = 0;
      const id = setInterval(() => {
        setDisplay(
          text
            .split("")
            .map((ch, idx) =>
              ch === " " ? " " : idx < i ? ch : CHARS[Math.floor(Math.random() * CHARS.length)]
            )
            .join("")
        );
        i++;
        if (i > text.length) { clearInterval(id); setDisplay(text); }
      }, 32);
    };
    glitch();
    const loop = setInterval(glitch, interval);
    return () => { clearInterval(loop); clearTimeout(timeout); };
  }, [text, interval]);
  return display;
}

// ─── Scanline overlay (CSS-only, no canvas) ───────────────────────────────────
const scanlineStyle: React.CSSProperties = {
  position: "fixed", inset: 0, zIndex: 1, pointerEvents: "none",
  backgroundImage:
    "repeating-linear-gradient(0deg, rgba(0,0,0,0.06) 0px, rgba(0,0,0,0.06) 1px, transparent 1px, transparent 4px)",
};

// ─── Noise grain overlay (generated once as a data URL) ───────────────────────
function NoiseOverlay() {
  const [src, setSrc] = useState("");
  useEffect(() => {
    const c = document.createElement("canvas");
    c.width = 256; c.height = 256;
    const ctx = c.getContext("2d")!;
    const d = ctx.createImageData(256, 256);
    for (let i = 0; i < d.data.length; i += 4) {
      const v = Math.floor(Math.random() * 255);
      d.data[i] = d.data[i+1] = d.data[i+2] = v;
      d.data[i+3] = 18;
    }
    ctx.putImageData(d, 0, 0);
    setSrc(c.toDataURL());
  }, []);
  if (!src) return null;
  return (
    <div
      style={{
        position: "fixed", inset: 0, zIndex: 2, pointerEvents: "none",
        backgroundImage: `url(${src})`,
        backgroundRepeat: "repeat",
        opacity: 0.55,
        mixBlendMode: "overlay",
      }}
    />
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function CenotaphPage() {
  const title = useGlitch("Cenotafio Fotónico");
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#080810",
        color: "#e8e8f0",
        fontFamily: "'Courier New', 'Lucida Console', monospace",
        overflow: "hidden",
        position: "relative",
      }}
    >
      {/* ── Layers ── */}
      <ParticleField />
      <div style={scanlineStyle} />
      <NoiseOverlay />

      {/* Radial red ambient from artifact position */}
      <div
        style={{
          position: "fixed",
          right: "8%", top: "15%",
          width: 600, height: 600,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,18,40,0.12) 0%, rgba(255,18,40,0.04) 40%, transparent 70%)",
          pointerEvents: "none",
          zIndex: 1,
          animation: "pulse 3.5s ease-in-out infinite",
        }}
      />

      {/* Vignette edges */}
      <div
        style={{
          position: "fixed", inset: 0, zIndex: 1, pointerEvents: "none",
          background: "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.65) 100%)",
        }}
      />

      {/* ── Content grid ── */}
      <div
        style={{
          position: "relative", zIndex: 10,
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          minHeight: "100vh",
          alignItems: "center",
          padding: "0 6%",
          gap: "2rem",
        }}
      >
        {/* LEFT — text */}
        <div style={{ maxWidth: 480 }}>
          {/* Eyebrow */}
          <div
            style={{
              display: "flex", alignItems: "center", gap: 10,
              marginBottom: 20, fontSize: 11,
              letterSpacing: "0.18em", color: "#555566",
            }}
          >
            <div style={{ width: 28, height: 1.5, background: "#ff1535" }} />
            MODELO PC-66
            <span style={{ color: "#333340" }}>·</span>
            CLASIFICACIÓN ALPHA
          </div>

          {/* Main title */}
          <h1 style={{ margin: 0, lineHeight: 1.0, marginBottom: 4 }}>
            <span
              style={{
                display: "block",
                fontSize: "clamp(2.6rem, 5vw, 4rem)",
                fontWeight: 700,
                color: "#ff1535",
                letterSpacing: "-0.02em",
                fontFamily: "inherit",
              }}
            >
              {mounted ? title : "Cenotafio Fotónico"}
            </span>
            <span
              style={{
                display: "block",
                fontSize: "clamp(2.6rem, 5vw, 4rem)",
                fontWeight: 300,
                color: "#e8e8f0",
                letterSpacing: "-0.02em",
              }}
            >
              de Código
            </span>
          </h1>

          {/* Divider */}
          <div
            style={{
              width: "100%", height: 1,
              background: "linear-gradient(90deg, rgba(255,21,53,0.6) 0%, transparent 100%)",
              margin: "24px 0",
            }}
          />

          {/* Description */}
          <p style={{ color: "#888898", fontSize: 14, lineHeight: 1.8, margin: "0 0 8px" }}>
            Hardware de Aislamiento Inmutable y Preservación de Caja Negra.
          </p>
          <p style={{ color: "#b8b8cc", fontSize: 14, fontWeight: 600, margin: "0 0 6px" }}>
            El algoritmo ya no se destruye.
          </p>
          <p style={{ color: "#555566", fontSize: 13, margin: 0 }}>
            Se condena a la posteridad inalterable.
          </p>

          {/* Spec grid */}
          <div
            style={{
              display: "grid", gridTemplateColumns: "1fr 1fr",
              gap: "10px 24px", marginTop: 36,
            }}
          >
            {[
              ["MODELO", "PH-CEN-X1"],
              ["TIPO", "DATA ISOLATOR"],
              ["SELLO", "VERIFICADO"],
              ["ESTADO", "ACTIVO"],
            ].map(([k, v]) => (
              <div key={k}>
                <div style={{ fontSize: 10, letterSpacing: "0.14em", color: "#444455", marginBottom: 3 }}>{k}</div>
                <div style={{ fontSize: 12, color: "#9999aa", letterSpacing: "0.06em" }}>{v}</div>
              </div>
            ))}
          </div>

          {/* CTA strip */}
          <div style={{ display: "flex", gap: 12, marginTop: 40 }}>
            <button
              style={{
                background: "transparent",
                border: "1px solid rgba(255,21,53,0.5)",
                color: "#ff1535",
                padding: "10px 22px",
                fontSize: 11,
                letterSpacing: "0.14em",
                cursor: "pointer",
                fontFamily: "inherit",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.background = "rgba(255,21,53,0.1)";
                (e.target as HTMLElement).style.borderColor = "#ff1535";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.background = "transparent";
                (e.target as HTMLElement).style.borderColor = "rgba(255,21,53,0.5)";
              }}
            >
              ESPECIFICACIONES
            </button>
            <button
              style={{
                background: "transparent",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "#666677",
                padding: "10px 22px",
                fontSize: 11,
                letterSpacing: "0.14em",
                cursor: "pointer",
                fontFamily: "inherit",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => {
                (e.target as HTMLElement).style.borderColor = "rgba(255,255,255,0.25)";
                (e.target as HTMLElement).style.color = "#9999aa";
              }}
              onMouseLeave={(e) => {
                (e.target as HTMLElement).style.borderColor = "rgba(255,255,255,0.1)";
                (e.target as HTMLElement).style.color = "#666677";
              }}
            >
              PROTOCOLO
            </button>
          </div>
        </div>

        {/* RIGHT — 3D artifact */}
        <div
          style={{
            height: "min(600px, 80vh)",
            position: "relative",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {/* Glow halo behind artifact */}
          <div
            style={{
              position: "absolute",
              inset: "10%",
              borderRadius: "50%",
              background: "radial-gradient(circle, rgba(255,20,40,0.08) 0%, transparent 70%)",
              filter: "blur(40px)",
              pointerEvents: "none",
              animation: "pulse 3.5s ease-in-out infinite",
            }}
          />
          <PhotonicCenotaph />
        </div>
      </div>

      {/* Bottom status bar */}
      <div
        style={{
          position: "fixed", bottom: 0, left: 0, right: 0,
          zIndex: 10,
          borderTop: "1px solid rgba(255,255,255,0.04)",
          background: "rgba(8,8,16,0.85)",
          backdropFilter: "blur(8px)",
          display: "flex", alignItems: "center",
          padding: "10px 6%", gap: 32,
          fontSize: 10, letterSpacing: "0.12em", color: "#333344",
        }}
      >
        <span>
          <span style={{ color: "#0044ff", marginRight: 6 }}>●</span>
          STANDBY
        </span>
        <span>S/N: MSG3C-2066-8734-X9</span>
        <span style={{ marginLeft: "auto", color: "#222233" }}>
          MOLECULAR CRYPTO-MATRIX · TYPE: INDUSTRIAL GRADE SECURE
        </span>
      </div>

      {/* Keyframes */}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.04); }
        }
      `}</style>
    </main>
  );
}
